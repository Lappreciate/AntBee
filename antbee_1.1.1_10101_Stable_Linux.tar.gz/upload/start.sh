
cd /ant/apps/antsentry-client/upload/
nohup java -jar /ant/apps/antsentry-client/upload/client-upload.jar >> /dev/null 2>&1 &

echo "$!" > /ant/apps/antsentry-client/pid/upload.pid