
app="/antsentry-client/monitor/client-monitor.jar"
ret=`ps -ef | grep "${app}" | grep -v grep | awk '{print $2}'`
if [[ -n ${ret} ]];
    then
    echo "stop the application"
    kill -9 ${ret}
fi
while true
do
    ret=`ps -ef | grep "${app}" | grep -v grep | awk '{print $2}'`
    echo "wait for stopping the application"
    if [[ -n ${ret} ]];
    then
        sleep 1
    else
        break
    fi
done
