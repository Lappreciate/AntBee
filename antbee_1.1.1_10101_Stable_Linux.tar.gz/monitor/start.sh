
cd /ant/apps/antsentry-client/monitor/
nohup java -jar /ant/apps/antsentry-client/monitor/client-monitor.jar >> /dev/null 2>&1 &


echo "$!" > /ant/apps/antsentry-client/pid/monitor.pid