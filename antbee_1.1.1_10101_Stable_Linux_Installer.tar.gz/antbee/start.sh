
cd /ant/apps/antsentry-client/antbee/
nohup java -jar /ant/apps/antsentry-client/antbee/client-antbee.jar >> /dev/null 2>&1 &

echo "$!" > /ant/apps/antsentry-client/pid/antbee.pid