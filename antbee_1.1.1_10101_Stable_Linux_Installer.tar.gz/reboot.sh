cd /ant/apps/antsentry-client/task/
java -jar /ant/apps/antsentry-client/task/client-task.jar reboot
