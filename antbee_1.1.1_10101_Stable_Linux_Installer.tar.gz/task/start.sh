
cd /ant/apps/antsentry-client/task/
nohup java -jar /ant/apps/antsentry-client/task/client-task.jar task >> /dev/null 2>&1 &

echo "$!" > /ant/apps/antsentry-client/pid/task.pid